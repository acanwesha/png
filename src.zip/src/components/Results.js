import React from 'react'
import Category from "./Category";

class Results extends React.Component {

    constructor () {
      super();
  
      this.state = {
        categories: [
          { title: 'Delivery Information', id: 0 },
          { title: 'Newborn Information', id: 1 },
          { title: 'Labor Information', id: 2 },
          { title: 'Complications', }
        ],
        items: [
          { title: 'PREGNANCY_OUTCOME', id: 0, category: { id: 0 } },
          { title: 'DATE_ TIME_OF_BIRTH', id: 1, category: { id: 0 } },
          { title: 'GESTATIONAL_AGE ', id: 2, category: { id: 0 } },
          { title: 'DELIVERY_ASSISTANCE', id: 3, category: { id: 0 } },
          { title: 'Item 5', id: 4, category: { id: 1 } },
          { title: 'Item 6', id: 5, category: { id: 2 } },
          { title: 'Item 7', id: 6, category: { id: 2 } }
        ],
        selectedCategoryId: null
      };
  
      this.onSelectCategory = this.onSelectCategory.bind(this);
    }
  
    onSelectCategory(id) {
      this.setState({
        selectedCategoryId: id
      });
    }
  
    render() {
      const { categories, items, selectedCategoryId } = this.state;
      const deafultCategory = Category.first(categories);
      const selectedCategory = Category.find(categories, i => i.id === selectedCategoryId) || deafultCategory;    
      return (
        <div>
          <CategoryFilter categories={categories} onSelectCategory={this.onSelectCategory} />
          <ItemList items={items} selectedCategory={selectedCategory} />
        </div>
      );
    }
  }
  
  var CategoryFilter = ({ categories, onSelectCategory}) => {
    const links = categories.map(i => (
      <div key={i.id}>
        <a href="/Results" onClick={() => onSelectCategory(i.id)}>
          { i.title }
        </a>
      </div>
    ));
    return (
      <div>
        { links }
      </div>
    )
  };
  
  var ItemList = ({items, selectedCategory}) => {
    const currentItems = items
      .filter(i => i.category.id === selectedCategory.id)
      .map(i => (
        <div key={i.id}>
          { i.title }
        </div>
      ));
    return (
      <div>
        { currentItems } 
      </div>
    );
  };
  
  
 export default Results